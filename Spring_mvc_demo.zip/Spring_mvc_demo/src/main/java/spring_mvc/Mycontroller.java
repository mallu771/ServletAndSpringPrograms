package spring_mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Mycontroller {

	@RequestMapping("hello")
	public void hello() {
		
		System.out.println("Hello HI");
	}
	@RequestMapping("bye")
	public void bye() {
		
		System.out.println("Hello HI bye");
	}
}
