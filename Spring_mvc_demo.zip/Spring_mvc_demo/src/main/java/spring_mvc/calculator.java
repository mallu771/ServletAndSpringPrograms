package spring_mvc;

import java.io.IOException;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class calculator {

//	@RequestMapping("add")
//	public void addition(HttpServletRequest request,HttpServletResponse response) throws IOException {
//		int num1=Integer.parseInt(request.getParameter("num1"));
//		int num2=Integer.parseInt(request.getParameter("num2"));
//		response.getWriter().print("<h1>Addition two number"+num1+" and "+num2+"is:"+(num1+num2)+"</h1>");
//		
//	}
//	@RequestMapping("sub")
//	public void substraction(@RequestParam int num1, @RequestParam int num2, HttpServletResponse response) throws IOException {
//		response.getWriter().print("<h1>Substraction two number"+num1+" and "+num2+"is:"+(num1-num2)+"</h1>");
//		
//	}
//	@RequestMapping("mul")
//	@ResponseBody
//	public String Multiplication(@RequestParam int num1, @RequestParam int num2) throws IOException {
//	  return "<h1>Substraction two number"+num1+" and "+num2+"is:"+(num1*num2)+"</h1>";
//		
//	}
	@RequestMapping("add")
	public ModelAndView addition(@RequestParam int num1, @RequestParam int num2) {
		ModelAndView andView=new ModelAndView();
		andView.addObject("num1", num1);
		andView.addObject("num2", num2);
		andView.addObject("msg", "Addition");
		andView.addObject("result",num1+num2);
		andView.setViewName("result.jsp");
		return andView;
		
	}
	@RequestMapping("sub")
	public ModelAndView substraction(@RequestParam int num1, @RequestParam int num2) {
		
		ModelAndView andView=new ModelAndView();
		andView.addObject("num1", num1);
		andView.addObject("num2", num2);
		andView.addObject("msg", "Substraction");
		andView.addObject("result",num1-num2);
		andView.setViewName("result.jsp");
		return andView;
		
	}
	@RequestMapping("mul")
	@ResponseBody
	public ModelAndView Multiplication(@RequestParam int num1, @RequestParam int num2)  {
		ModelAndView andView=new ModelAndView();
		andView.addObject("num1", num1);
		andView.addObject("num2", num2);
		andView.addObject("msg", "Multiplication");
		andView.addObject("result",num1*num2);
		andView.setViewName("result.jsp");
		return andView;
		
		
	}
	@RequestMapping("div")
	public ModelAndView Division(@RequestParam int num1, @RequestParam int num2){
		ModelAndView andView=new ModelAndView();
//		andView.addObject("x", num1);
//		andView.addObject("y", num2);
		andView.addObject("num1", num1);
		andView.addObject("num2", num2);
		andView.addObject("msg", "Division");
		andView.addObject("result",num1/num2);
		andView.setViewName("result.jsp");
		return andView;
		
	}
}
